package com.example.meznahsulaiman.e_menu;

import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;


public class foods extends ActionBarActivity {

    ListView lv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_foods);

        ArrayList<ListItem> items = new ArrayList<ListItem>();
        items.add(new ListItem(R.drawable.s2));
        items.add(new ListItem(R.drawable.s2));
        items.add(new ListItem(R.drawable.s2));
        items.add(new ListItem(R.drawable.s2));
        MyCustomAdapterFoods MyAdapter= new MyCustomAdapterFoods(items);

        ListView ls=(ListView)findViewById(R.id.listView_foods);
        ls.setAdapter(MyAdapter);
        ls.setOnItemClickListener(MyAdapter);
    }

    class MyCustomAdapterFoods extends BaseAdapter implements AdapterView.OnItemClickListener
    {
        ArrayList<ListItem> items = new ArrayList<ListItem>();
        MyCustomAdapterFoods(ArrayList<ListItem> items)
        {
            this.items=items;
        }



        @Override
        public int getCount()
        {
            return items.size();

        }

        @Override
        public Object getItem(int position)
        {
            return items.get(position);

        }

        @Override
        public long getItemId(int position)
        {
            return position;

        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup)
        {
            LayoutInflater layoutInflater= getLayoutInflater();
            View view1 = layoutInflater.inflate(R.layout.row_view, null);

            ImageView image = (ImageView) view1.findViewById(R.id.imageView);
            ListItem temp = items.get(i);
            image.setImageResource(temp.img);


            return view1;

        }

        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            ViewGroup vg= (ViewGroup) view;
            ImageView image = (ImageView) view.findViewById(R.id.imageView);


            Intent i = new Intent(getApplicationContext(),foodContents.class);

            i.putExtra("Position",position);
            startActivity(i);




            //  imgid=(Integer)image.getId();
            // count = items.indexOf(R.drawable.s1);


            // resName = getResourceNameFromClassByID(R.drawable.class, R.drawable.s1);





        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_foods, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
