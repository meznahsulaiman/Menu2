package com.example.meznahsulaiman.e_menu;

/**
 * Created by meznahSulaiman on 7/25/16.
 */
public class ListItem {
    public int img;

    ListItem(int img)
    {
        this.img=img;
    }
}

