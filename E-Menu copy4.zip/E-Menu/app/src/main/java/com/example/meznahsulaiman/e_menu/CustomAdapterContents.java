package com.example.meznahsulaiman.e_menu;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by meznahSulaiman on 7/28/16.
 */
public class CustomAdapterContents extends BaseAdapter{

    private Context c;
    String[] names={"Browni","Date Cheese cake","Browni2","Date Cheese cake2"};
    String[] desc={"Chocolate cake with chips","cake with date","Chocolate cake with chips2","cake with date2"};
    int[] imgs={R.drawable.s1,R.drawable.s1,R.drawable.s1,R.drawable.s1};

    public CustomAdapterContents(Context ctx)
    {
        this.c=ctx;
    }
    @Override
    public int getCount() {
        return names.length;
    }

    @Override
    public Object getItem(int position) {
        return names[position];
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        if (convertView == null)
        {
            LayoutInflater layoutInflater=(LayoutInflater) c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = layoutInflater.inflate(R.layout.contents, null);


        }
        //Get Views

        ImageView imgname=(ImageView) convertView.findViewById(R.id.imageView_disp);
        TextView txtname = (TextView) convertView.findViewById(R.id.textView_name);
        TextView txtdesc = (TextView) convertView.findViewById(R.id.textView_desc);

        //ListItem temp = items.get(i);
        //image.setImageResource(temp.img);

        imgname.setImageResource(imgs[position]);
       txtname.setText(names[position]);
        txtdesc.setText(desc[position]);

        return convertView;
    }



}
