package com.example.meznahsulaiman.e_menu;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by meznahSulaiman on 7/29/16.
 */
public class CustomAdapterColdContents extends BaseAdapter {

    private Context c;

    String[] names={"Moka1","Moka2","Moka3","Moka4"};
    String[] desc={"Milk with chocolate1","Milk with chocolate2","Milk with chocolate3","Milk with chocolate4"};
    int[] imgs={R.drawable.s4,R.drawable.s4,R.drawable.s4,R.drawable.s4};

    public CustomAdapterColdContents(Context ctx)
    {
        this.c=ctx;
    }
    @Override
    public int getCount() {
        return names.length;
    }

    @Override
    public Object getItem(int position) {
        return names[position];
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        if (convertView == null)
        {
            LayoutInflater layoutInflater=(LayoutInflater) c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = layoutInflater.inflate(R.layout.contents, null);


        }
        //Get Views

        ImageView imgname=(ImageView) convertView.findViewById(R.id.imageView_disp);
        TextView txtname = (TextView) convertView.findViewById(R.id.textView_name);
        TextView txtdesc = (TextView) convertView.findViewById(R.id.textView_desc);

        //ListItem temp = items.get(i);
        //image.setImageResource(temp.img);

        imgname.setImageResource(imgs[position]);
        txtname.setText(names[position]);
        txtdesc.setText(desc[position]);

        return convertView;
    }



}
