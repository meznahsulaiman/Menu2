package com.example.meznahsulaiman.e_menu;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by meznahSulaiman on 7/29/16.
 */
public class CustomAdapterFoodContents extends BaseAdapter {

    private Context c;
    String[] names={"Rice1","Rice2","Rice3","Rice4"};
    String[] desc={"Rice with chicken1","Rice with chicken2","Rice with chicken3","Rice with chicken4"};
    int[] imgs={R.drawable.s2,R.drawable.s2,R.drawable.s2,R.drawable.s2};

    public CustomAdapterFoodContents(Context ctx)
    {
        this.c=ctx;
    }
    @Override
    public int getCount() {
        return names.length;
    }

    @Override
    public Object getItem(int position) {
        return names[position];
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        if (convertView == null)
        {
            LayoutInflater layoutInflater=(LayoutInflater) c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = layoutInflater.inflate(R.layout.contents, null);


        }
        //Get Views

        ImageView imgname=(ImageView) convertView.findViewById(R.id.imageView_disp);
        TextView txtname = (TextView) convertView.findViewById(R.id.textView_name);
        TextView txtdesc = (TextView) convertView.findViewById(R.id.textView_desc);

        //ListItem temp = items.get(i);
        //image.setImageResource(temp.img);

        imgname.setImageResource(imgs[position]);
        txtname.setText(names[position]);
        txtdesc.setText(desc[position]);

        return convertView;
    }



}
