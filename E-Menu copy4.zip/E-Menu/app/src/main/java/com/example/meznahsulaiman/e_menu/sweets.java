package com.example.meznahsulaiman.e_menu;

import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;


import java.util.ArrayList;


public class sweets extends ActionBarActivity {

    ListView lv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sweets);

        ArrayList<ListItem> items = new ArrayList<ListItem>();
        items.add(new ListItem(R.drawable.s1));
        items.add(new ListItem(R.drawable.s1));
        items.add(new ListItem(R.drawable.s1));
        items.add(new ListItem(R.drawable.s1));

        MyCustomAdapterSweets MyAdapter= new MyCustomAdapterSweets(items);

        ListView ls=(ListView)findViewById(R.id.listView_sweets);
        ls.setAdapter(MyAdapter);
        ls.setOnItemClickListener(MyAdapter);
///////////
        /*lv=(ListView)findViewById(R.id.listView_sweets);
        CustomAdapterContents adapter = new CustomAdapterContents(this);
        lv.setAdapter(adapter);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent i = new Intent(getApplicationContext(),Content.class);

                i.putExtra("Position",position);
                startActivity(i);

            }
        });*/
    }

    class MyCustomAdapterSweets extends BaseAdapter implements AdapterView.OnItemClickListener
    {
        ArrayList<ListItem> items = new ArrayList<ListItem>();
        MyCustomAdapterSweets(ArrayList<ListItem> items)
        {
            this.items=items;
        }



        @Override
        public int getCount()
        {
            return items.size();

        }

        @Override
        public Object getItem(int position)
        {
            return items.get(position);

        }

        @Override
        public long getItemId(int position)
        {
            return position;

        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup)
        {
            LayoutInflater layoutInflater= getLayoutInflater();
            View view1 = layoutInflater.inflate(R.layout.row_view, null);

            ImageView image = (ImageView) view1.findViewById(R.id.imageView);
            ListItem temp = items.get(i);
            image.setImageResource(temp.img);


            return view1;

        }

        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            ViewGroup vg= (ViewGroup) view;
            ImageView image = (ImageView) view.findViewById(R.id.imageView);



                Intent i = new Intent(getApplicationContext(),Content.class);

                i.putExtra("Position",position);
                startActivity(i);
               //Toast.makeText(getApplicationContext(), "Hello1", Toast.LENGTH_SHORT).show();

        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_sweets, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
